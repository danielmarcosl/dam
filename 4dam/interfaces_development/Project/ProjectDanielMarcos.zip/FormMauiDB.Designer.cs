﻿namespace ADO
{
    partial class FormMauiDB
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMauiDB));
            this.listViewEmpleado = new System.Windows.Forms.ListView();
            this.columnHeaderEM = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderNombreEmpleado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderApellidosEmpleado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderTurnoEmpleado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.labelEM = new System.Windows.Forms.Label();
            this.textBoxApellidosEmpleado = new System.Windows.Forms.TextBox();
            this.labelNombre = new System.Windows.Forms.Label();
            this.textBoxNombreEmpleado = new System.Windows.Forms.TextBox();
            this.labelApellidosEmpleado = new System.Windows.Forms.Label();
            this.textBoxTurnoEmpleado = new System.Windows.Forms.TextBox();
            this.labelTurnoempleado = new System.Windows.Forms.Label();
            this.textBoxEM = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageLibros = new System.Windows.Forms.TabPage();
            this.buttonCargarLibros = new System.Windows.Forms.Button();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPageCategorias = new System.Windows.Forms.TabPage();
            this.buttonCategoriaBorrar = new System.Windows.Forms.Button();
            this.buttonCategoriaCrear = new System.Windows.Forms.Button();
            this.buttonCategoriaActualizar = new System.Windows.Forms.Button();
            this.labelCategoriaAutor = new System.Windows.Forms.Label();
            this.labelCategoriaEditorial = new System.Windows.Forms.Label();
            this.labelCategoriaFecha = new System.Windows.Forms.Label();
            this.textBoxCategoriaLI = new System.Windows.Forms.TextBox();
            this.textBoxCategoriaFecha = new System.Windows.Forms.TextBox();
            this.textBoxCategoriaNombre = new System.Windows.Forms.TextBox();
            this.labelCategoriaNombre = new System.Windows.Forms.Label();
            this.textBoxCategoriaAutor = new System.Windows.Forms.TextBox();
            this.textBoxCategoriaEditorial = new System.Windows.Forms.TextBox();
            this.labelCategoriaLI = new System.Windows.Forms.Label();
            this.listViewCategoria = new System.Windows.Forms.ListView();
            this.columnHeaderCategoriaLV = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderCountCategoria = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewCategoriaLibro = new System.Windows.Forms.ListView();
            this.columnHeaderLICategoria = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderNombreCategoria = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderFechaCategoria = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderEditorialCategoria = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderAutorCategoria = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPageEstilos = new System.Windows.Forms.TabPage();
            this.buttonEstiloBorrar = new System.Windows.Forms.Button();
            this.buttonEstiloCrear = new System.Windows.Forms.Button();
            this.buttonEstiloActualizar = new System.Windows.Forms.Button();
            this.labelEstiloAutor = new System.Windows.Forms.Label();
            this.labelEstiloEditorial = new System.Windows.Forms.Label();
            this.labelEstiloFecha = new System.Windows.Forms.Label();
            this.textBoxEstiloLI = new System.Windows.Forms.TextBox();
            this.textBoxEstiloFecha = new System.Windows.Forms.TextBox();
            this.textBoxEstiloNombre = new System.Windows.Forms.TextBox();
            this.labelEstiloNombre = new System.Windows.Forms.Label();
            this.textBoxEstiloAutor = new System.Windows.Forms.TextBox();
            this.textBoxEstiloEditorial = new System.Windows.Forms.TextBox();
            this.labelEstiloLI = new System.Windows.Forms.Label();
            this.listViewEstilo = new System.Windows.Forms.ListView();
            this.columnHeaderEstiloLV = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderCountEstilo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewEstiloLibro = new System.Windows.Forms.ListView();
            this.columnHeaderLIEstilo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderNombreEstilo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderFechaEstilo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderEditorialEstilo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderAutorEstilo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPageAutores = new System.Windows.Forms.TabPage();
            this.buttonAutorBorrar = new System.Windows.Forms.Button();
            this.buttonAutorCrear = new System.Windows.Forms.Button();
            this.buttonAutorActualizar = new System.Windows.Forms.Button();
            this.labelAutorEditorial = new System.Windows.Forms.Label();
            this.labelAutorFecha = new System.Windows.Forms.Label();
            this.textBoxAutorLI = new System.Windows.Forms.TextBox();
            this.textBoxAutorFecha = new System.Windows.Forms.TextBox();
            this.textBoxAutorNombre = new System.Windows.Forms.TextBox();
            this.labelAutorNombre = new System.Windows.Forms.Label();
            this.textBoxAutorEditorial = new System.Windows.Forms.TextBox();
            this.labelAutorLI = new System.Windows.Forms.Label();
            this.listViewAutores = new System.Windows.Forms.ListView();
            this.columnHeaderAutorLV = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderCountAutor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewAutoresLibro = new System.Windows.Forms.ListView();
            this.columnHeaderLIAutor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderNombreAutor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderFechaAutor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderEditorialAutor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPagePersonas = new System.Windows.Forms.TabPage();
            this.buttonCargarPersonas = new System.Windows.Forms.Button();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPageEmpleados = new System.Windows.Forms.TabPage();
            this.buttonBorrarEmpleado = new System.Windows.Forms.Button();
            this.buttonCrearEmpleado = new System.Windows.Forms.Button();
            this.buttonActualizarEmpleado = new System.Windows.Forms.Button();
            this.tabPageUsuarios = new System.Windows.Forms.TabPage();
            this.buttonBorrarUsuario = new System.Windows.Forms.Button();
            this.buttonCrearUsuario = new System.Windows.Forms.Button();
            this.buttonActualizarUsuario = new System.Windows.Forms.Button();
            this.labelDireccionUsuario = new System.Windows.Forms.Label();
            this.labelApellidosUsuario = new System.Windows.Forms.Label();
            this.textBoxUS = new System.Windows.Forms.TextBox();
            this.textBoxApellidosUsuario = new System.Windows.Forms.TextBox();
            this.textBoxNombreUsuario = new System.Windows.Forms.TextBox();
            this.labelNombreUsuario = new System.Windows.Forms.Label();
            this.textBoxDireccionUsuario = new System.Windows.Forms.TextBox();
            this.labelUS = new System.Windows.Forms.Label();
            this.listViewUsuario = new System.Windows.Forms.ListView();
            this.columnHeaderUS = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderNombreUsuario = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderApellidosUsuario = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderDireccionUsuario = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPagePrestamo = new System.Windows.Forms.TabPage();
            this.buttonPrestamosCrear = new System.Windows.Forms.Button();
            this.buttonPrestamosActualizar = new System.Windows.Forms.Button();
            this.textBoxPrestamosFechaEntrega = new System.Windows.Forms.TextBox();
            this.labelPrestamosFechaEntrega = new System.Windows.Forms.Label();
            this.textBoxPrestamosPR = new System.Windows.Forms.TextBox();
            this.labelPrestamosPR = new System.Windows.Forms.Label();
            this.textBoxPrestamosFechaRecogida = new System.Windows.Forms.TextBox();
            this.labelPrestamosFechaRecogida = new System.Windows.Forms.Label();
            this.listViewPrestamos = new System.Windows.Forms.ListView();
            this.columnHeaderPrestamoPR = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderPrestamoRecogida = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderPrestamoEntrega = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderPrestamoUsuario = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderPrestamoLibro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderPrestamoEmpleado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.buttonCargarPrestamos = new System.Windows.Forms.Button();
            this.labelPrestamosEmpleado = new System.Windows.Forms.Label();
            this.labelPrestamosLibro = new System.Windows.Forms.Label();
            this.labelPrestamosUsuario = new System.Windows.Forms.Label();
            this.imageListAplicacion = new System.Windows.Forms.ImageList(this.components);
            this.buttonClose = new System.Windows.Forms.Button();
            this.buttonAcercaDe = new System.Windows.Forms.Button();
            this.textBoxPrestamosUsuario = new System.Windows.Forms.TextBox();
            this.textBoxPrestamosEmpleado = new System.Windows.Forms.TextBox();
            this.textBoxPrestamosLibro = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPageLibros.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPageCategorias.SuspendLayout();
            this.tabPageEstilos.SuspendLayout();
            this.tabPageAutores.SuspendLayout();
            this.tabPagePersonas.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPageEmpleados.SuspendLayout();
            this.tabPageUsuarios.SuspendLayout();
            this.tabPagePrestamo.SuspendLayout();
            this.SuspendLayout();
            // 
            // listViewEmpleado
            // 
            this.listViewEmpleado.BackColor = System.Drawing.Color.WhiteSmoke;
            this.listViewEmpleado.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderEM,
            this.columnHeaderNombreEmpleado,
            this.columnHeaderApellidosEmpleado,
            this.columnHeaderTurnoEmpleado});
            this.listViewEmpleado.FullRowSelect = true;
            this.listViewEmpleado.Location = new System.Drawing.Point(5, 6);
            this.listViewEmpleado.MultiSelect = false;
            this.listViewEmpleado.Name = "listViewEmpleado";
            this.listViewEmpleado.Size = new System.Drawing.Size(682, 218);
            this.listViewEmpleado.TabIndex = 3;
            this.listViewEmpleado.UseCompatibleStateImageBehavior = false;
            this.listViewEmpleado.View = System.Windows.Forms.View.Details;
            this.listViewEmpleado.SelectedIndexChanged += new System.EventHandler(this.listViewEmpleado_SelectedIndexChanged);
            this.listViewEmpleado.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown_1);
            this.listViewEmpleado.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.listViewEmpleado.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // columnHeaderEM
            // 
            this.columnHeaderEM.Text = "EM#";
            this.columnHeaderEM.Width = 69;
            // 
            // columnHeaderNombreEmpleado
            // 
            this.columnHeaderNombreEmpleado.Text = "Nombre";
            this.columnHeaderNombreEmpleado.Width = 148;
            // 
            // columnHeaderApellidosEmpleado
            // 
            this.columnHeaderApellidosEmpleado.Text = "Apellidos";
            this.columnHeaderApellidosEmpleado.Width = 148;
            // 
            // columnHeaderTurnoEmpleado
            // 
            this.columnHeaderTurnoEmpleado.Text = "Turno";
            this.columnHeaderTurnoEmpleado.Width = 114;
            // 
            // labelEM
            // 
            this.labelEM.AutoSize = true;
            this.labelEM.Location = new System.Drawing.Point(22, 244);
            this.labelEM.Name = "labelEM";
            this.labelEM.Size = new System.Drawing.Size(50, 26);
            this.labelEM.TabIndex = 4;
            this.labelEM.Text = "EM#";
            // 
            // textBoxApellidosEmpleado
            // 
            this.textBoxApellidosEmpleado.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxApellidosEmpleado.Location = new System.Drawing.Point(127, 309);
            this.textBoxApellidosEmpleado.Name = "textBoxApellidosEmpleado";
            this.textBoxApellidosEmpleado.Size = new System.Drawing.Size(144, 33);
            this.textBoxApellidosEmpleado.TabIndex = 5;
            // 
            // labelNombre
            // 
            this.labelNombre.AutoSize = true;
            this.labelNombre.Location = new System.Drawing.Point(22, 278);
            this.labelNombre.Name = "labelNombre";
            this.labelNombre.Size = new System.Drawing.Size(82, 26);
            this.labelNombre.TabIndex = 4;
            this.labelNombre.Text = "Nombre";
            // 
            // textBoxNombreEmpleado
            // 
            this.textBoxNombreEmpleado.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxNombreEmpleado.Location = new System.Drawing.Point(127, 275);
            this.textBoxNombreEmpleado.Name = "textBoxNombreEmpleado";
            this.textBoxNombreEmpleado.Size = new System.Drawing.Size(144, 33);
            this.textBoxNombreEmpleado.TabIndex = 5;
            // 
            // labelApellidosEmpleado
            // 
            this.labelApellidosEmpleado.AutoSize = true;
            this.labelApellidosEmpleado.Location = new System.Drawing.Point(22, 312);
            this.labelApellidosEmpleado.Name = "labelApellidosEmpleado";
            this.labelApellidosEmpleado.Size = new System.Drawing.Size(90, 26);
            this.labelApellidosEmpleado.TabIndex = 4;
            this.labelApellidosEmpleado.Text = "Apellidos";
            // 
            // textBoxTurnoEmpleado
            // 
            this.textBoxTurnoEmpleado.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxTurnoEmpleado.Location = new System.Drawing.Point(127, 343);
            this.textBoxTurnoEmpleado.Name = "textBoxTurnoEmpleado";
            this.textBoxTurnoEmpleado.Size = new System.Drawing.Size(144, 33);
            this.textBoxTurnoEmpleado.TabIndex = 5;
            // 
            // labelTurnoempleado
            // 
            this.labelTurnoempleado.AutoSize = true;
            this.labelTurnoempleado.Location = new System.Drawing.Point(22, 346);
            this.labelTurnoempleado.Name = "labelTurnoempleado";
            this.labelTurnoempleado.Size = new System.Drawing.Size(61, 26);
            this.labelTurnoempleado.TabIndex = 4;
            this.labelTurnoempleado.Text = "Turno";
            // 
            // textBoxEM
            // 
            this.textBoxEM.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxEM.Location = new System.Drawing.Point(127, 241);
            this.textBoxEM.Name = "textBoxEM";
            this.textBoxEM.Size = new System.Drawing.Size(144, 33);
            this.textBoxEM.TabIndex = 5;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageLibros);
            this.tabControl1.Controls.Add(this.tabPagePersonas);
            this.tabControl1.Controls.Add(this.tabPagePrestamo);
            this.tabControl1.ImageList = this.imageListAplicacion;
            this.tabControl1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tabControl1.Location = new System.Drawing.Point(-5, -3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(706, 480);
            this.tabControl1.TabIndex = 6;
            this.tabControl1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown_1);
            this.tabControl1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.tabControl1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // tabPageLibros
            // 
            this.tabPageLibros.BackColor = System.Drawing.Color.Gainsboro;
            this.tabPageLibros.Controls.Add(this.buttonCargarLibros);
            this.tabPageLibros.Controls.Add(this.tabControl3);
            this.tabPageLibros.ImageIndex = 0;
            this.tabPageLibros.Location = new System.Drawing.Point(4, 39);
            this.tabPageLibros.Name = "tabPageLibros";
            this.tabPageLibros.Size = new System.Drawing.Size(698, 437);
            this.tabPageLibros.TabIndex = 2;
            this.tabPageLibros.Text = "Libros";
            this.tabPageLibros.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown_1);
            this.tabPageLibros.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.tabPageLibros.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // buttonCargarLibros
            // 
            this.buttonCargarLibros.BackColor = System.Drawing.Color.Gainsboro;
            this.buttonCargarLibros.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.buttonCargarLibros.FlatAppearance.BorderSize = 0;
            this.buttonCargarLibros.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCargarLibros.ForeColor = System.Drawing.Color.Black;
            this.buttonCargarLibros.Location = new System.Drawing.Point(537, -4);
            this.buttonCargarLibros.Margin = new System.Windows.Forms.Padding(0);
            this.buttonCargarLibros.Name = "buttonCargarLibros";
            this.buttonCargarLibros.Size = new System.Drawing.Size(155, 40);
            this.buttonCargarLibros.TabIndex = 9;
            this.buttonCargarLibros.Text = "Cargar Libros";
            this.buttonCargarLibros.UseVisualStyleBackColor = false;
            this.buttonCargarLibros.Click += new System.EventHandler(this.buttonCargarLibros_Click);
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPageCategorias);
            this.tabControl3.Controls.Add(this.tabPageEstilos);
            this.tabControl3.Controls.Add(this.tabPageAutores);
            this.tabControl3.Location = new System.Drawing.Point(-2, 1);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(702, 440);
            this.tabControl3.TabIndex = 8;
            this.tabControl3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown_1);
            this.tabControl3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.tabControl3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // tabPageCategorias
            // 
            this.tabPageCategorias.BackColor = System.Drawing.Color.Gainsboro;
            this.tabPageCategorias.Controls.Add(this.buttonCategoriaBorrar);
            this.tabPageCategorias.Controls.Add(this.buttonCategoriaCrear);
            this.tabPageCategorias.Controls.Add(this.buttonCategoriaActualizar);
            this.tabPageCategorias.Controls.Add(this.labelCategoriaAutor);
            this.tabPageCategorias.Controls.Add(this.labelCategoriaEditorial);
            this.tabPageCategorias.Controls.Add(this.labelCategoriaFecha);
            this.tabPageCategorias.Controls.Add(this.textBoxCategoriaLI);
            this.tabPageCategorias.Controls.Add(this.textBoxCategoriaFecha);
            this.tabPageCategorias.Controls.Add(this.textBoxCategoriaNombre);
            this.tabPageCategorias.Controls.Add(this.labelCategoriaNombre);
            this.tabPageCategorias.Controls.Add(this.textBoxCategoriaAutor);
            this.tabPageCategorias.Controls.Add(this.textBoxCategoriaEditorial);
            this.tabPageCategorias.Controls.Add(this.labelCategoriaLI);
            this.tabPageCategorias.Controls.Add(this.listViewCategoria);
            this.tabPageCategorias.Controls.Add(this.listViewCategoriaLibro);
            this.tabPageCategorias.Location = new System.Drawing.Point(4, 35);
            this.tabPageCategorias.Name = "tabPageCategorias";
            this.tabPageCategorias.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCategorias.Size = new System.Drawing.Size(694, 401);
            this.tabPageCategorias.TabIndex = 1;
            this.tabPageCategorias.Text = "Categorias";
            this.tabPageCategorias.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown_1);
            this.tabPageCategorias.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.tabPageCategorias.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // buttonCategoriaBorrar
            // 
            this.buttonCategoriaBorrar.Location = new System.Drawing.Point(535, 296);
            this.buttonCategoriaBorrar.Name = "buttonCategoriaBorrar";
            this.buttonCategoriaBorrar.Size = new System.Drawing.Size(113, 34);
            this.buttonCategoriaBorrar.TabIndex = 63;
            this.buttonCategoriaBorrar.Text = "Borrar";
            this.buttonCategoriaBorrar.UseVisualStyleBackColor = true;
            this.buttonCategoriaBorrar.Click += new System.EventHandler(this.buttonCategoriaBorrar_Click);
            // 
            // buttonCategoriaCrear
            // 
            this.buttonCategoriaCrear.Location = new System.Drawing.Point(535, 338);
            this.buttonCategoriaCrear.Name = "buttonCategoriaCrear";
            this.buttonCategoriaCrear.Size = new System.Drawing.Size(113, 34);
            this.buttonCategoriaCrear.TabIndex = 62;
            this.buttonCategoriaCrear.Text = "Crear";
            this.buttonCategoriaCrear.UseVisualStyleBackColor = true;
            this.buttonCategoriaCrear.Click += new System.EventHandler(this.buttonCategoriaCrear_Click);
            // 
            // buttonCategoriaActualizar
            // 
            this.buttonCategoriaActualizar.Location = new System.Drawing.Point(535, 254);
            this.buttonCategoriaActualizar.Name = "buttonCategoriaActualizar";
            this.buttonCategoriaActualizar.Size = new System.Drawing.Size(113, 34);
            this.buttonCategoriaActualizar.TabIndex = 61;
            this.buttonCategoriaActualizar.Text = "Actualizar";
            this.buttonCategoriaActualizar.UseVisualStyleBackColor = true;
            this.buttonCategoriaActualizar.Click += new System.EventHandler(this.buttonCategoriaActualizar_Click);
            // 
            // labelCategoriaAutor
            // 
            this.labelCategoriaAutor.AutoSize = true;
            this.labelCategoriaAutor.Location = new System.Drawing.Point(233, 365);
            this.labelCategoriaAutor.Name = "labelCategoriaAutor";
            this.labelCategoriaAutor.Size = new System.Drawing.Size(60, 26);
            this.labelCategoriaAutor.TabIndex = 51;
            this.labelCategoriaAutor.Text = "Autor";
            // 
            // labelCategoriaEditorial
            // 
            this.labelCategoriaEditorial.AutoSize = true;
            this.labelCategoriaEditorial.Location = new System.Drawing.Point(233, 330);
            this.labelCategoriaEditorial.Name = "labelCategoriaEditorial";
            this.labelCategoriaEditorial.Size = new System.Drawing.Size(83, 26);
            this.labelCategoriaEditorial.TabIndex = 52;
            this.labelCategoriaEditorial.Text = "Editorial";
            // 
            // labelCategoriaFecha
            // 
            this.labelCategoriaFecha.AutoSize = true;
            this.labelCategoriaFecha.Location = new System.Drawing.Point(233, 296);
            this.labelCategoriaFecha.Name = "labelCategoriaFecha";
            this.labelCategoriaFecha.Size = new System.Drawing.Size(62, 26);
            this.labelCategoriaFecha.TabIndex = 53;
            this.labelCategoriaFecha.Text = "Fecha";
            // 
            // textBoxCategoriaLI
            // 
            this.textBoxCategoriaLI.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxCategoriaLI.Location = new System.Drawing.Point(338, 225);
            this.textBoxCategoriaLI.Name = "textBoxCategoriaLI";
            this.textBoxCategoriaLI.Size = new System.Drawing.Size(144, 33);
            this.textBoxCategoriaLI.TabIndex = 60;
            // 
            // textBoxCategoriaFecha
            // 
            this.textBoxCategoriaFecha.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxCategoriaFecha.Location = new System.Drawing.Point(338, 293);
            this.textBoxCategoriaFecha.Name = "textBoxCategoriaFecha";
            this.textBoxCategoriaFecha.Size = new System.Drawing.Size(144, 33);
            this.textBoxCategoriaFecha.TabIndex = 59;
            // 
            // textBoxCategoriaNombre
            // 
            this.textBoxCategoriaNombre.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxCategoriaNombre.Location = new System.Drawing.Point(338, 259);
            this.textBoxCategoriaNombre.Name = "textBoxCategoriaNombre";
            this.textBoxCategoriaNombre.Size = new System.Drawing.Size(144, 33);
            this.textBoxCategoriaNombre.TabIndex = 56;
            // 
            // labelCategoriaNombre
            // 
            this.labelCategoriaNombre.AutoSize = true;
            this.labelCategoriaNombre.Location = new System.Drawing.Point(233, 262);
            this.labelCategoriaNombre.Name = "labelCategoriaNombre";
            this.labelCategoriaNombre.Size = new System.Drawing.Size(82, 26);
            this.labelCategoriaNombre.TabIndex = 54;
            this.labelCategoriaNombre.Text = "Nombre";
            // 
            // textBoxCategoriaAutor
            // 
            this.textBoxCategoriaAutor.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxCategoriaAutor.Location = new System.Drawing.Point(338, 362);
            this.textBoxCategoriaAutor.Name = "textBoxCategoriaAutor";
            this.textBoxCategoriaAutor.Size = new System.Drawing.Size(144, 33);
            this.textBoxCategoriaAutor.TabIndex = 57;
            // 
            // textBoxCategoriaEditorial
            // 
            this.textBoxCategoriaEditorial.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxCategoriaEditorial.Location = new System.Drawing.Point(338, 327);
            this.textBoxCategoriaEditorial.Name = "textBoxCategoriaEditorial";
            this.textBoxCategoriaEditorial.Size = new System.Drawing.Size(144, 33);
            this.textBoxCategoriaEditorial.TabIndex = 58;
            // 
            // labelCategoriaLI
            // 
            this.labelCategoriaLI.AutoSize = true;
            this.labelCategoriaLI.Location = new System.Drawing.Point(233, 228);
            this.labelCategoriaLI.Name = "labelCategoriaLI";
            this.labelCategoriaLI.Size = new System.Drawing.Size(36, 26);
            this.labelCategoriaLI.TabIndex = 55;
            this.labelCategoriaLI.Text = "LI#";
            // 
            // listViewCategoria
            // 
            this.listViewCategoria.BackColor = System.Drawing.Color.WhiteSmoke;
            this.listViewCategoria.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderCategoriaLV,
            this.columnHeaderCountCategoria});
            this.listViewCategoria.FullRowSelect = true;
            this.listViewCategoria.Location = new System.Drawing.Point(3, 228);
            this.listViewCategoria.MultiSelect = false;
            this.listViewCategoria.Name = "listViewCategoria";
            this.listViewCategoria.Size = new System.Drawing.Size(223, 168);
            this.listViewCategoria.TabIndex = 24;
            this.listViewCategoria.UseCompatibleStateImageBehavior = false;
            this.listViewCategoria.View = System.Windows.Forms.View.Details;
            // 
            // columnHeaderCategoriaLV
            // 
            this.columnHeaderCategoriaLV.Text = "Categoria";
            this.columnHeaderCategoriaLV.Width = 116;
            // 
            // columnHeaderCountCategoria
            // 
            this.columnHeaderCountCategoria.Text = "Num.";
            // 
            // listViewCategoriaLibro
            // 
            this.listViewCategoriaLibro.BackColor = System.Drawing.Color.WhiteSmoke;
            this.listViewCategoriaLibro.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderLICategoria,
            this.columnHeaderNombreCategoria,
            this.columnHeaderFechaCategoria,
            this.columnHeaderEditorialCategoria,
            this.columnHeaderAutorCategoria});
            this.listViewCategoriaLibro.FullRowSelect = true;
            this.listViewCategoriaLibro.Location = new System.Drawing.Point(3, 6);
            this.listViewCategoriaLibro.MultiSelect = false;
            this.listViewCategoriaLibro.Name = "listViewCategoriaLibro";
            this.listViewCategoriaLibro.Size = new System.Drawing.Size(682, 218);
            this.listViewCategoriaLibro.TabIndex = 3;
            this.listViewCategoriaLibro.UseCompatibleStateImageBehavior = false;
            this.listViewCategoriaLibro.View = System.Windows.Forms.View.Details;
            this.listViewCategoriaLibro.SelectedIndexChanged += new System.EventHandler(this.listViewCategoriaLibro_SelectedIndexChanged);
            // 
            // columnHeaderLICategoria
            // 
            this.columnHeaderLICategoria.Text = "LI#";
            this.columnHeaderLICategoria.Width = 69;
            // 
            // columnHeaderNombreCategoria
            // 
            this.columnHeaderNombreCategoria.Text = "Nombre";
            this.columnHeaderNombreCategoria.Width = 204;
            // 
            // columnHeaderFechaCategoria
            // 
            this.columnHeaderFechaCategoria.Text = "Fecha";
            this.columnHeaderFechaCategoria.Width = 148;
            // 
            // columnHeaderEditorialCategoria
            // 
            this.columnHeaderEditorialCategoria.Text = "Editorial";
            this.columnHeaderEditorialCategoria.Width = 114;
            // 
            // columnHeaderAutorCategoria
            // 
            this.columnHeaderAutorCategoria.Text = "Autor";
            this.columnHeaderAutorCategoria.Width = 141;
            // 
            // tabPageEstilos
            // 
            this.tabPageEstilos.BackColor = System.Drawing.Color.Gainsboro;
            this.tabPageEstilos.Controls.Add(this.buttonEstiloBorrar);
            this.tabPageEstilos.Controls.Add(this.buttonEstiloCrear);
            this.tabPageEstilos.Controls.Add(this.buttonEstiloActualizar);
            this.tabPageEstilos.Controls.Add(this.labelEstiloAutor);
            this.tabPageEstilos.Controls.Add(this.labelEstiloEditorial);
            this.tabPageEstilos.Controls.Add(this.labelEstiloFecha);
            this.tabPageEstilos.Controls.Add(this.textBoxEstiloLI);
            this.tabPageEstilos.Controls.Add(this.textBoxEstiloFecha);
            this.tabPageEstilos.Controls.Add(this.textBoxEstiloNombre);
            this.tabPageEstilos.Controls.Add(this.labelEstiloNombre);
            this.tabPageEstilos.Controls.Add(this.textBoxEstiloAutor);
            this.tabPageEstilos.Controls.Add(this.textBoxEstiloEditorial);
            this.tabPageEstilos.Controls.Add(this.labelEstiloLI);
            this.tabPageEstilos.Controls.Add(this.listViewEstilo);
            this.tabPageEstilos.Controls.Add(this.listViewEstiloLibro);
            this.tabPageEstilos.Location = new System.Drawing.Point(4, 35);
            this.tabPageEstilos.Name = "tabPageEstilos";
            this.tabPageEstilos.Size = new System.Drawing.Size(694, 401);
            this.tabPageEstilos.TabIndex = 2;
            this.tabPageEstilos.Text = "Estilos";
            this.tabPageEstilos.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown_1);
            this.tabPageEstilos.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.tabPageEstilos.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // buttonEstiloBorrar
            // 
            this.buttonEstiloBorrar.Location = new System.Drawing.Point(535, 296);
            this.buttonEstiloBorrar.Name = "buttonEstiloBorrar";
            this.buttonEstiloBorrar.Size = new System.Drawing.Size(113, 34);
            this.buttonEstiloBorrar.TabIndex = 50;
            this.buttonEstiloBorrar.Text = "Borrar";
            this.buttonEstiloBorrar.UseVisualStyleBackColor = true;
            this.buttonEstiloBorrar.Click += new System.EventHandler(this.buttonEstiloBorrar_Click);
            // 
            // buttonEstiloCrear
            // 
            this.buttonEstiloCrear.Location = new System.Drawing.Point(535, 338);
            this.buttonEstiloCrear.Name = "buttonEstiloCrear";
            this.buttonEstiloCrear.Size = new System.Drawing.Size(113, 34);
            this.buttonEstiloCrear.TabIndex = 49;
            this.buttonEstiloCrear.Text = "Crear";
            this.buttonEstiloCrear.UseVisualStyleBackColor = true;
            this.buttonEstiloCrear.Click += new System.EventHandler(this.buttonEstiloCrear_Click);
            // 
            // buttonEstiloActualizar
            // 
            this.buttonEstiloActualizar.Location = new System.Drawing.Point(535, 254);
            this.buttonEstiloActualizar.Name = "buttonEstiloActualizar";
            this.buttonEstiloActualizar.Size = new System.Drawing.Size(113, 34);
            this.buttonEstiloActualizar.TabIndex = 48;
            this.buttonEstiloActualizar.Text = "Actualizar";
            this.buttonEstiloActualizar.UseVisualStyleBackColor = true;
            this.buttonEstiloActualizar.Click += new System.EventHandler(this.buttonEstiloActualizar_Click);
            // 
            // labelEstiloAutor
            // 
            this.labelEstiloAutor.AutoSize = true;
            this.labelEstiloAutor.Location = new System.Drawing.Point(233, 365);
            this.labelEstiloAutor.Name = "labelEstiloAutor";
            this.labelEstiloAutor.Size = new System.Drawing.Size(60, 26);
            this.labelEstiloAutor.TabIndex = 38;
            this.labelEstiloAutor.Text = "Autor";
            // 
            // labelEstiloEditorial
            // 
            this.labelEstiloEditorial.AutoSize = true;
            this.labelEstiloEditorial.Location = new System.Drawing.Point(233, 330);
            this.labelEstiloEditorial.Name = "labelEstiloEditorial";
            this.labelEstiloEditorial.Size = new System.Drawing.Size(83, 26);
            this.labelEstiloEditorial.TabIndex = 39;
            this.labelEstiloEditorial.Text = "Editorial";
            // 
            // labelEstiloFecha
            // 
            this.labelEstiloFecha.AutoSize = true;
            this.labelEstiloFecha.Location = new System.Drawing.Point(233, 296);
            this.labelEstiloFecha.Name = "labelEstiloFecha";
            this.labelEstiloFecha.Size = new System.Drawing.Size(62, 26);
            this.labelEstiloFecha.TabIndex = 40;
            this.labelEstiloFecha.Text = "Fecha";
            // 
            // textBoxEstiloLI
            // 
            this.textBoxEstiloLI.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxEstiloLI.Location = new System.Drawing.Point(338, 225);
            this.textBoxEstiloLI.Name = "textBoxEstiloLI";
            this.textBoxEstiloLI.Size = new System.Drawing.Size(144, 33);
            this.textBoxEstiloLI.TabIndex = 47;
            // 
            // textBoxEstiloFecha
            // 
            this.textBoxEstiloFecha.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxEstiloFecha.Location = new System.Drawing.Point(338, 293);
            this.textBoxEstiloFecha.Name = "textBoxEstiloFecha";
            this.textBoxEstiloFecha.Size = new System.Drawing.Size(144, 33);
            this.textBoxEstiloFecha.TabIndex = 46;
            // 
            // textBoxEstiloNombre
            // 
            this.textBoxEstiloNombre.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxEstiloNombre.Location = new System.Drawing.Point(338, 259);
            this.textBoxEstiloNombre.Name = "textBoxEstiloNombre";
            this.textBoxEstiloNombre.Size = new System.Drawing.Size(144, 33);
            this.textBoxEstiloNombre.TabIndex = 43;
            // 
            // labelEstiloNombre
            // 
            this.labelEstiloNombre.AutoSize = true;
            this.labelEstiloNombre.Location = new System.Drawing.Point(233, 262);
            this.labelEstiloNombre.Name = "labelEstiloNombre";
            this.labelEstiloNombre.Size = new System.Drawing.Size(82, 26);
            this.labelEstiloNombre.TabIndex = 41;
            this.labelEstiloNombre.Text = "Nombre";
            // 
            // textBoxEstiloAutor
            // 
            this.textBoxEstiloAutor.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxEstiloAutor.Location = new System.Drawing.Point(338, 362);
            this.textBoxEstiloAutor.Name = "textBoxEstiloAutor";
            this.textBoxEstiloAutor.Size = new System.Drawing.Size(144, 33);
            this.textBoxEstiloAutor.TabIndex = 44;
            // 
            // textBoxEstiloEditorial
            // 
            this.textBoxEstiloEditorial.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxEstiloEditorial.Location = new System.Drawing.Point(338, 327);
            this.textBoxEstiloEditorial.Name = "textBoxEstiloEditorial";
            this.textBoxEstiloEditorial.Size = new System.Drawing.Size(144, 33);
            this.textBoxEstiloEditorial.TabIndex = 45;
            // 
            // labelEstiloLI
            // 
            this.labelEstiloLI.AutoSize = true;
            this.labelEstiloLI.Location = new System.Drawing.Point(233, 228);
            this.labelEstiloLI.Name = "labelEstiloLI";
            this.labelEstiloLI.Size = new System.Drawing.Size(36, 26);
            this.labelEstiloLI.TabIndex = 42;
            this.labelEstiloLI.Text = "LI#";
            // 
            // listViewEstilo
            // 
            this.listViewEstilo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.listViewEstilo.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderEstiloLV,
            this.columnHeaderCountEstilo});
            this.listViewEstilo.FullRowSelect = true;
            this.listViewEstilo.Location = new System.Drawing.Point(3, 228);
            this.listViewEstilo.MultiSelect = false;
            this.listViewEstilo.Name = "listViewEstilo";
            this.listViewEstilo.Size = new System.Drawing.Size(223, 168);
            this.listViewEstilo.TabIndex = 25;
            this.listViewEstilo.UseCompatibleStateImageBehavior = false;
            this.listViewEstilo.View = System.Windows.Forms.View.Details;
            // 
            // columnHeaderEstiloLV
            // 
            this.columnHeaderEstiloLV.Text = "Estilo";
            this.columnHeaderEstiloLV.Width = 116;
            // 
            // columnHeaderCountEstilo
            // 
            this.columnHeaderCountEstilo.Text = "Num.";
            // 
            // listViewEstiloLibro
            // 
            this.listViewEstiloLibro.BackColor = System.Drawing.Color.WhiteSmoke;
            this.listViewEstiloLibro.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderLIEstilo,
            this.columnHeaderNombreEstilo,
            this.columnHeaderFechaEstilo,
            this.columnHeaderEditorialEstilo,
            this.columnHeaderAutorEstilo});
            this.listViewEstiloLibro.FullRowSelect = true;
            this.listViewEstiloLibro.Location = new System.Drawing.Point(3, 6);
            this.listViewEstiloLibro.MultiSelect = false;
            this.listViewEstiloLibro.Name = "listViewEstiloLibro";
            this.listViewEstiloLibro.Size = new System.Drawing.Size(682, 218);
            this.listViewEstiloLibro.TabIndex = 24;
            this.listViewEstiloLibro.UseCompatibleStateImageBehavior = false;
            this.listViewEstiloLibro.View = System.Windows.Forms.View.Details;
            this.listViewEstiloLibro.SelectedIndexChanged += new System.EventHandler(this.listViewEstiloLibro_SelectedIndexChanged);
            // 
            // columnHeaderLIEstilo
            // 
            this.columnHeaderLIEstilo.Text = "LI#";
            this.columnHeaderLIEstilo.Width = 69;
            // 
            // columnHeaderNombreEstilo
            // 
            this.columnHeaderNombreEstilo.Text = "Nombre";
            this.columnHeaderNombreEstilo.Width = 204;
            // 
            // columnHeaderFechaEstilo
            // 
            this.columnHeaderFechaEstilo.Text = "Fecha";
            this.columnHeaderFechaEstilo.Width = 148;
            // 
            // columnHeaderEditorialEstilo
            // 
            this.columnHeaderEditorialEstilo.Text = "Editorial";
            this.columnHeaderEditorialEstilo.Width = 114;
            // 
            // columnHeaderAutorEstilo
            // 
            this.columnHeaderAutorEstilo.Text = "Autor";
            this.columnHeaderAutorEstilo.Width = 141;
            // 
            // tabPageAutores
            // 
            this.tabPageAutores.BackColor = System.Drawing.Color.Gainsboro;
            this.tabPageAutores.Controls.Add(this.buttonAutorBorrar);
            this.tabPageAutores.Controls.Add(this.buttonAutorCrear);
            this.tabPageAutores.Controls.Add(this.buttonAutorActualizar);
            this.tabPageAutores.Controls.Add(this.labelAutorEditorial);
            this.tabPageAutores.Controls.Add(this.labelAutorFecha);
            this.tabPageAutores.Controls.Add(this.textBoxAutorLI);
            this.tabPageAutores.Controls.Add(this.textBoxAutorFecha);
            this.tabPageAutores.Controls.Add(this.textBoxAutorNombre);
            this.tabPageAutores.Controls.Add(this.labelAutorNombre);
            this.tabPageAutores.Controls.Add(this.textBoxAutorEditorial);
            this.tabPageAutores.Controls.Add(this.labelAutorLI);
            this.tabPageAutores.Controls.Add(this.listViewAutores);
            this.tabPageAutores.Controls.Add(this.listViewAutoresLibro);
            this.tabPageAutores.Location = new System.Drawing.Point(4, 35);
            this.tabPageAutores.Name = "tabPageAutores";
            this.tabPageAutores.Size = new System.Drawing.Size(694, 401);
            this.tabPageAutores.TabIndex = 3;
            this.tabPageAutores.Text = "Autores";
            this.tabPageAutores.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown_1);
            this.tabPageAutores.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.tabPageAutores.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // buttonAutorBorrar
            // 
            this.buttonAutorBorrar.Location = new System.Drawing.Point(535, 296);
            this.buttonAutorBorrar.Name = "buttonAutorBorrar";
            this.buttonAutorBorrar.Size = new System.Drawing.Size(113, 34);
            this.buttonAutorBorrar.TabIndex = 37;
            this.buttonAutorBorrar.Text = "Borrar";
            this.buttonAutorBorrar.UseVisualStyleBackColor = true;
            this.buttonAutorBorrar.Click += new System.EventHandler(this.buttonAutorBorrar_Click);
            // 
            // buttonAutorCrear
            // 
            this.buttonAutorCrear.Location = new System.Drawing.Point(535, 338);
            this.buttonAutorCrear.Name = "buttonAutorCrear";
            this.buttonAutorCrear.Size = new System.Drawing.Size(113, 34);
            this.buttonAutorCrear.TabIndex = 36;
            this.buttonAutorCrear.Text = "Crear";
            this.buttonAutorCrear.UseVisualStyleBackColor = true;
            this.buttonAutorCrear.Click += new System.EventHandler(this.buttonAutorCrear_Click);
            // 
            // buttonAutorActualizar
            // 
            this.buttonAutorActualizar.Location = new System.Drawing.Point(535, 254);
            this.buttonAutorActualizar.Name = "buttonAutorActualizar";
            this.buttonAutorActualizar.Size = new System.Drawing.Size(113, 34);
            this.buttonAutorActualizar.TabIndex = 35;
            this.buttonAutorActualizar.Text = "Actualizar";
            this.buttonAutorActualizar.UseVisualStyleBackColor = true;
            this.buttonAutorActualizar.Click += new System.EventHandler(this.buttonAutorActualizar_Click);
            // 
            // labelAutorEditorial
            // 
            this.labelAutorEditorial.AutoSize = true;
            this.labelAutorEditorial.Location = new System.Drawing.Point(233, 348);
            this.labelAutorEditorial.Name = "labelAutorEditorial";
            this.labelAutorEditorial.Size = new System.Drawing.Size(83, 26);
            this.labelAutorEditorial.TabIndex = 27;
            this.labelAutorEditorial.Text = "Editorial";
            // 
            // labelAutorFecha
            // 
            this.labelAutorFecha.AutoSize = true;
            this.labelAutorFecha.Location = new System.Drawing.Point(233, 314);
            this.labelAutorFecha.Name = "labelAutorFecha";
            this.labelAutorFecha.Size = new System.Drawing.Size(62, 26);
            this.labelAutorFecha.TabIndex = 28;
            this.labelAutorFecha.Text = "Fecha";
            // 
            // textBoxAutorLI
            // 
            this.textBoxAutorLI.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxAutorLI.Location = new System.Drawing.Point(338, 243);
            this.textBoxAutorLI.Name = "textBoxAutorLI";
            this.textBoxAutorLI.Size = new System.Drawing.Size(144, 33);
            this.textBoxAutorLI.TabIndex = 34;
            // 
            // textBoxAutorFecha
            // 
            this.textBoxAutorFecha.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxAutorFecha.Location = new System.Drawing.Point(338, 311);
            this.textBoxAutorFecha.Name = "textBoxAutorFecha";
            this.textBoxAutorFecha.Size = new System.Drawing.Size(144, 33);
            this.textBoxAutorFecha.TabIndex = 33;
            // 
            // textBoxAutorNombre
            // 
            this.textBoxAutorNombre.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxAutorNombre.Location = new System.Drawing.Point(338, 277);
            this.textBoxAutorNombre.Name = "textBoxAutorNombre";
            this.textBoxAutorNombre.Size = new System.Drawing.Size(144, 33);
            this.textBoxAutorNombre.TabIndex = 31;
            // 
            // labelAutorNombre
            // 
            this.labelAutorNombre.AutoSize = true;
            this.labelAutorNombre.Location = new System.Drawing.Point(233, 280);
            this.labelAutorNombre.Name = "labelAutorNombre";
            this.labelAutorNombre.Size = new System.Drawing.Size(82, 26);
            this.labelAutorNombre.TabIndex = 29;
            this.labelAutorNombre.Text = "Nombre";
            // 
            // textBoxAutorEditorial
            // 
            this.textBoxAutorEditorial.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxAutorEditorial.Location = new System.Drawing.Point(338, 345);
            this.textBoxAutorEditorial.Name = "textBoxAutorEditorial";
            this.textBoxAutorEditorial.Size = new System.Drawing.Size(144, 33);
            this.textBoxAutorEditorial.TabIndex = 32;
            // 
            // labelAutorLI
            // 
            this.labelAutorLI.AutoSize = true;
            this.labelAutorLI.Location = new System.Drawing.Point(233, 246);
            this.labelAutorLI.Name = "labelAutorLI";
            this.labelAutorLI.Size = new System.Drawing.Size(36, 26);
            this.labelAutorLI.TabIndex = 30;
            this.labelAutorLI.Text = "LI#";
            // 
            // listViewAutores
            // 
            this.listViewAutores.BackColor = System.Drawing.Color.WhiteSmoke;
            this.listViewAutores.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderAutorLV,
            this.columnHeaderCountAutor});
            this.listViewAutores.FullRowSelect = true;
            this.listViewAutores.Location = new System.Drawing.Point(3, 228);
            this.listViewAutores.MultiSelect = false;
            this.listViewAutores.Name = "listViewAutores";
            this.listViewAutores.Size = new System.Drawing.Size(223, 168);
            this.listViewAutores.TabIndex = 26;
            this.listViewAutores.UseCompatibleStateImageBehavior = false;
            this.listViewAutores.View = System.Windows.Forms.View.Details;
            // 
            // columnHeaderAutorLV
            // 
            this.columnHeaderAutorLV.Text = "Autor";
            this.columnHeaderAutorLV.Width = 116;
            // 
            // columnHeaderCountAutor
            // 
            this.columnHeaderCountAutor.Text = "Num.";
            // 
            // listViewAutoresLibro
            // 
            this.listViewAutoresLibro.BackColor = System.Drawing.Color.WhiteSmoke;
            this.listViewAutoresLibro.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderLIAutor,
            this.columnHeaderNombreAutor,
            this.columnHeaderFechaAutor,
            this.columnHeaderEditorialAutor});
            this.listViewAutoresLibro.FullRowSelect = true;
            this.listViewAutoresLibro.Location = new System.Drawing.Point(3, 6);
            this.listViewAutoresLibro.MultiSelect = false;
            this.listViewAutoresLibro.Name = "listViewAutoresLibro";
            this.listViewAutoresLibro.Size = new System.Drawing.Size(682, 218);
            this.listViewAutoresLibro.TabIndex = 24;
            this.listViewAutoresLibro.UseCompatibleStateImageBehavior = false;
            this.listViewAutoresLibro.View = System.Windows.Forms.View.Details;
            this.listViewAutoresLibro.SelectedIndexChanged += new System.EventHandler(this.listViewAutoresLibro_SelectedIndexChanged);
            // 
            // columnHeaderLIAutor
            // 
            this.columnHeaderLIAutor.Text = "LI#";
            this.columnHeaderLIAutor.Width = 69;
            // 
            // columnHeaderNombreAutor
            // 
            this.columnHeaderNombreAutor.Text = "Nombre";
            this.columnHeaderNombreAutor.Width = 204;
            // 
            // columnHeaderFechaAutor
            // 
            this.columnHeaderFechaAutor.Text = "Fecha";
            this.columnHeaderFechaAutor.Width = 148;
            // 
            // columnHeaderEditorialAutor
            // 
            this.columnHeaderEditorialAutor.Text = "Editorial";
            this.columnHeaderEditorialAutor.Width = 114;
            // 
            // tabPagePersonas
            // 
            this.tabPagePersonas.BackColor = System.Drawing.Color.Gainsboro;
            this.tabPagePersonas.Controls.Add(this.buttonCargarPersonas);
            this.tabPagePersonas.Controls.Add(this.tabControl2);
            this.tabPagePersonas.ImageIndex = 1;
            this.tabPagePersonas.Location = new System.Drawing.Point(4, 39);
            this.tabPagePersonas.Name = "tabPagePersonas";
            this.tabPagePersonas.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePersonas.Size = new System.Drawing.Size(698, 437);
            this.tabPagePersonas.TabIndex = 1;
            this.tabPagePersonas.Text = "Personas";
            this.tabPagePersonas.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown_1);
            this.tabPagePersonas.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.tabPagePersonas.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // buttonCargarPersonas
            // 
            this.buttonCargarPersonas.BackColor = System.Drawing.Color.Gainsboro;
            this.buttonCargarPersonas.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.buttonCargarPersonas.FlatAppearance.BorderSize = 0;
            this.buttonCargarPersonas.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCargarPersonas.ForeColor = System.Drawing.Color.Black;
            this.buttonCargarPersonas.Location = new System.Drawing.Point(532, -4);
            this.buttonCargarPersonas.Margin = new System.Windows.Forms.Padding(0);
            this.buttonCargarPersonas.Name = "buttonCargarPersonas";
            this.buttonCargarPersonas.Size = new System.Drawing.Size(160, 40);
            this.buttonCargarPersonas.TabIndex = 9;
            this.buttonCargarPersonas.Text = "Cargar Personas";
            this.buttonCargarPersonas.UseVisualStyleBackColor = false;
            this.buttonCargarPersonas.Click += new System.EventHandler(this.buttonCargarPersonas_Click);
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPageEmpleados);
            this.tabControl2.Controls.Add(this.tabPageUsuarios);
            this.tabControl2.Location = new System.Drawing.Point(-4, 1);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(702, 440);
            this.tabControl2.TabIndex = 7;
            this.tabControl2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown_1);
            this.tabControl2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.tabControl2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // tabPageEmpleados
            // 
            this.tabPageEmpleados.BackColor = System.Drawing.Color.Gainsboro;
            this.tabPageEmpleados.Controls.Add(this.buttonBorrarEmpleado);
            this.tabPageEmpleados.Controls.Add(this.buttonCrearEmpleado);
            this.tabPageEmpleados.Controls.Add(this.listViewEmpleado);
            this.tabPageEmpleados.Controls.Add(this.buttonActualizarEmpleado);
            this.tabPageEmpleados.Controls.Add(this.labelTurnoempleado);
            this.tabPageEmpleados.Controls.Add(this.labelApellidosEmpleado);
            this.tabPageEmpleados.Controls.Add(this.textBoxEM);
            this.tabPageEmpleados.Controls.Add(this.textBoxApellidosEmpleado);
            this.tabPageEmpleados.Controls.Add(this.textBoxNombreEmpleado);
            this.tabPageEmpleados.Controls.Add(this.labelNombre);
            this.tabPageEmpleados.Controls.Add(this.textBoxTurnoEmpleado);
            this.tabPageEmpleados.Controls.Add(this.labelEM);
            this.tabPageEmpleados.Location = new System.Drawing.Point(4, 35);
            this.tabPageEmpleados.Name = "tabPageEmpleados";
            this.tabPageEmpleados.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEmpleados.Size = new System.Drawing.Size(694, 401);
            this.tabPageEmpleados.TabIndex = 1;
            this.tabPageEmpleados.Text = "Empleados";
            this.tabPageEmpleados.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown_1);
            this.tabPageEmpleados.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.tabPageEmpleados.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // buttonBorrarEmpleado
            // 
            this.buttonBorrarEmpleado.Location = new System.Drawing.Point(286, 289);
            this.buttonBorrarEmpleado.Name = "buttonBorrarEmpleado";
            this.buttonBorrarEmpleado.Size = new System.Drawing.Size(113, 34);
            this.buttonBorrarEmpleado.TabIndex = 8;
            this.buttonBorrarEmpleado.Text = "Borrar";
            this.buttonBorrarEmpleado.UseVisualStyleBackColor = true;
            this.buttonBorrarEmpleado.Click += new System.EventHandler(this.buttonBorrarEmpleado_Click);
            // 
            // buttonCrearEmpleado
            // 
            this.buttonCrearEmpleado.Location = new System.Drawing.Point(286, 331);
            this.buttonCrearEmpleado.Name = "buttonCrearEmpleado";
            this.buttonCrearEmpleado.Size = new System.Drawing.Size(113, 34);
            this.buttonCrearEmpleado.TabIndex = 7;
            this.buttonCrearEmpleado.Text = "Crear";
            this.buttonCrearEmpleado.UseVisualStyleBackColor = true;
            this.buttonCrearEmpleado.Click += new System.EventHandler(this.buttonCrearEmpleado_Click);
            // 
            // buttonActualizarEmpleado
            // 
            this.buttonActualizarEmpleado.Location = new System.Drawing.Point(286, 247);
            this.buttonActualizarEmpleado.Name = "buttonActualizarEmpleado";
            this.buttonActualizarEmpleado.Size = new System.Drawing.Size(113, 34);
            this.buttonActualizarEmpleado.TabIndex = 6;
            this.buttonActualizarEmpleado.Text = "Actualizar";
            this.buttonActualizarEmpleado.UseVisualStyleBackColor = true;
            this.buttonActualizarEmpleado.Click += new System.EventHandler(this.buttonActualizarEmpleado_Click);
            // 
            // tabPageUsuarios
            // 
            this.tabPageUsuarios.BackColor = System.Drawing.Color.Gainsboro;
            this.tabPageUsuarios.Controls.Add(this.buttonBorrarUsuario);
            this.tabPageUsuarios.Controls.Add(this.buttonCrearUsuario);
            this.tabPageUsuarios.Controls.Add(this.buttonActualizarUsuario);
            this.tabPageUsuarios.Controls.Add(this.labelDireccionUsuario);
            this.tabPageUsuarios.Controls.Add(this.labelApellidosUsuario);
            this.tabPageUsuarios.Controls.Add(this.textBoxUS);
            this.tabPageUsuarios.Controls.Add(this.textBoxApellidosUsuario);
            this.tabPageUsuarios.Controls.Add(this.textBoxNombreUsuario);
            this.tabPageUsuarios.Controls.Add(this.labelNombreUsuario);
            this.tabPageUsuarios.Controls.Add(this.textBoxDireccionUsuario);
            this.tabPageUsuarios.Controls.Add(this.labelUS);
            this.tabPageUsuarios.Controls.Add(this.listViewUsuario);
            this.tabPageUsuarios.Location = new System.Drawing.Point(4, 35);
            this.tabPageUsuarios.Name = "tabPageUsuarios";
            this.tabPageUsuarios.Size = new System.Drawing.Size(694, 401);
            this.tabPageUsuarios.TabIndex = 2;
            this.tabPageUsuarios.Text = "Usuarios";
            this.tabPageUsuarios.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown_1);
            this.tabPageUsuarios.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.tabPageUsuarios.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // buttonBorrarUsuario
            // 
            this.buttonBorrarUsuario.Location = new System.Drawing.Point(286, 289);
            this.buttonBorrarUsuario.Name = "buttonBorrarUsuario";
            this.buttonBorrarUsuario.Size = new System.Drawing.Size(113, 34);
            this.buttonBorrarUsuario.TabIndex = 21;
            this.buttonBorrarUsuario.Text = "Borrar";
            this.buttonBorrarUsuario.UseVisualStyleBackColor = true;
            this.buttonBorrarUsuario.Click += new System.EventHandler(this.buttonBorrarUsuario_Click);
            // 
            // buttonCrearUsuario
            // 
            this.buttonCrearUsuario.Location = new System.Drawing.Point(286, 331);
            this.buttonCrearUsuario.Name = "buttonCrearUsuario";
            this.buttonCrearUsuario.Size = new System.Drawing.Size(113, 34);
            this.buttonCrearUsuario.TabIndex = 20;
            this.buttonCrearUsuario.Text = "Crear";
            this.buttonCrearUsuario.UseVisualStyleBackColor = true;
            this.buttonCrearUsuario.Click += new System.EventHandler(this.buttonCrearUsuario_Click);
            // 
            // buttonActualizarUsuario
            // 
            this.buttonActualizarUsuario.Location = new System.Drawing.Point(286, 247);
            this.buttonActualizarUsuario.Name = "buttonActualizarUsuario";
            this.buttonActualizarUsuario.Size = new System.Drawing.Size(113, 34);
            this.buttonActualizarUsuario.TabIndex = 19;
            this.buttonActualizarUsuario.Text = "Actualizar";
            this.buttonActualizarUsuario.UseVisualStyleBackColor = true;
            this.buttonActualizarUsuario.Click += new System.EventHandler(this.buttonActualizarUsuario_Click);
            // 
            // labelDireccionUsuario
            // 
            this.labelDireccionUsuario.AutoSize = true;
            this.labelDireccionUsuario.Location = new System.Drawing.Point(22, 346);
            this.labelDireccionUsuario.Name = "labelDireccionUsuario";
            this.labelDireccionUsuario.Size = new System.Drawing.Size(92, 26);
            this.labelDireccionUsuario.TabIndex = 11;
            this.labelDireccionUsuario.Text = "Dirección";
            // 
            // labelApellidosUsuario
            // 
            this.labelApellidosUsuario.AutoSize = true;
            this.labelApellidosUsuario.Location = new System.Drawing.Point(22, 312);
            this.labelApellidosUsuario.Name = "labelApellidosUsuario";
            this.labelApellidosUsuario.Size = new System.Drawing.Size(90, 26);
            this.labelApellidosUsuario.TabIndex = 14;
            this.labelApellidosUsuario.Text = "Apellidos";
            // 
            // textBoxUS
            // 
            this.textBoxUS.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxUS.Location = new System.Drawing.Point(127, 241);
            this.textBoxUS.Name = "textBoxUS";
            this.textBoxUS.Size = new System.Drawing.Size(144, 33);
            this.textBoxUS.TabIndex = 15;
            // 
            // textBoxApellidosUsuario
            // 
            this.textBoxApellidosUsuario.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxApellidosUsuario.Location = new System.Drawing.Point(127, 309);
            this.textBoxApellidosUsuario.Name = "textBoxApellidosUsuario";
            this.textBoxApellidosUsuario.Size = new System.Drawing.Size(144, 33);
            this.textBoxApellidosUsuario.TabIndex = 18;
            // 
            // textBoxNombreUsuario
            // 
            this.textBoxNombreUsuario.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxNombreUsuario.Location = new System.Drawing.Point(127, 275);
            this.textBoxNombreUsuario.Name = "textBoxNombreUsuario";
            this.textBoxNombreUsuario.Size = new System.Drawing.Size(144, 33);
            this.textBoxNombreUsuario.TabIndex = 16;
            // 
            // labelNombreUsuario
            // 
            this.labelNombreUsuario.AutoSize = true;
            this.labelNombreUsuario.Location = new System.Drawing.Point(22, 278);
            this.labelNombreUsuario.Name = "labelNombreUsuario";
            this.labelNombreUsuario.Size = new System.Drawing.Size(82, 26);
            this.labelNombreUsuario.TabIndex = 13;
            this.labelNombreUsuario.Text = "Nombre";
            // 
            // textBoxDireccionUsuario
            // 
            this.textBoxDireccionUsuario.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxDireccionUsuario.Location = new System.Drawing.Point(127, 343);
            this.textBoxDireccionUsuario.Name = "textBoxDireccionUsuario";
            this.textBoxDireccionUsuario.Size = new System.Drawing.Size(144, 33);
            this.textBoxDireccionUsuario.TabIndex = 17;
            // 
            // labelUS
            // 
            this.labelUS.AutoSize = true;
            this.labelUS.Location = new System.Drawing.Point(22, 244);
            this.labelUS.Name = "labelUS";
            this.labelUS.Size = new System.Drawing.Size(45, 26);
            this.labelUS.TabIndex = 12;
            this.labelUS.Text = "US#";
            // 
            // listViewUsuario
            // 
            this.listViewUsuario.BackColor = System.Drawing.Color.WhiteSmoke;
            this.listViewUsuario.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderUS,
            this.columnHeaderNombreUsuario,
            this.columnHeaderApellidosUsuario,
            this.columnHeaderDireccionUsuario});
            this.listViewUsuario.FullRowSelect = true;
            this.listViewUsuario.Location = new System.Drawing.Point(5, 6);
            this.listViewUsuario.MultiSelect = false;
            this.listViewUsuario.Name = "listViewUsuario";
            this.listViewUsuario.Size = new System.Drawing.Size(682, 218);
            this.listViewUsuario.TabIndex = 10;
            this.listViewUsuario.UseCompatibleStateImageBehavior = false;
            this.listViewUsuario.View = System.Windows.Forms.View.Details;
            this.listViewUsuario.SelectedIndexChanged += new System.EventHandler(this.listViewUsuario_SelectedIndexChanged);
            this.listViewUsuario.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown_1);
            this.listViewUsuario.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.listViewUsuario.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // columnHeaderUS
            // 
            this.columnHeaderUS.Text = "US#";
            this.columnHeaderUS.Width = 69;
            // 
            // columnHeaderNombreUsuario
            // 
            this.columnHeaderNombreUsuario.Text = "Nombre";
            this.columnHeaderNombreUsuario.Width = 148;
            // 
            // columnHeaderApellidosUsuario
            // 
            this.columnHeaderApellidosUsuario.Text = "Apellidos";
            this.columnHeaderApellidosUsuario.Width = 148;
            // 
            // columnHeaderDireccionUsuario
            // 
            this.columnHeaderDireccionUsuario.Text = "Direccion";
            this.columnHeaderDireccionUsuario.Width = 114;
            // 
            // tabPagePrestamo
            // 
            this.tabPagePrestamo.BackColor = System.Drawing.Color.Gainsboro;
            this.tabPagePrestamo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.tabPagePrestamo.CausesValidation = false;
            this.tabPagePrestamo.Controls.Add(this.buttonPrestamosCrear);
            this.tabPagePrestamo.Controls.Add(this.buttonPrestamosActualizar);
            this.tabPagePrestamo.Controls.Add(this.textBoxPrestamosFechaEntrega);
            this.tabPagePrestamo.Controls.Add(this.labelPrestamosFechaEntrega);
            this.tabPagePrestamo.Controls.Add(this.textBoxPrestamosLibro);
            this.tabPagePrestamo.Controls.Add(this.textBoxPrestamosEmpleado);
            this.tabPagePrestamo.Controls.Add(this.textBoxPrestamosUsuario);
            this.tabPagePrestamo.Controls.Add(this.textBoxPrestamosPR);
            this.tabPagePrestamo.Controls.Add(this.labelPrestamosPR);
            this.tabPagePrestamo.Controls.Add(this.textBoxPrestamosFechaRecogida);
            this.tabPagePrestamo.Controls.Add(this.labelPrestamosFechaRecogida);
            this.tabPagePrestamo.Controls.Add(this.listViewPrestamos);
            this.tabPagePrestamo.Controls.Add(this.buttonCargarPrestamos);
            this.tabPagePrestamo.Controls.Add(this.labelPrestamosEmpleado);
            this.tabPagePrestamo.Controls.Add(this.labelPrestamosLibro);
            this.tabPagePrestamo.Controls.Add(this.labelPrestamosUsuario);
            this.tabPagePrestamo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tabPagePrestamo.ImageIndex = 2;
            this.tabPagePrestamo.Location = new System.Drawing.Point(4, 39);
            this.tabPagePrestamo.Margin = new System.Windows.Forms.Padding(0);
            this.tabPagePrestamo.Name = "tabPagePrestamo";
            this.tabPagePrestamo.Size = new System.Drawing.Size(698, 437);
            this.tabPagePrestamo.TabIndex = 0;
            this.tabPagePrestamo.Text = "Préstamo";
            this.tabPagePrestamo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown_1);
            this.tabPagePrestamo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.tabPagePrestamo.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // buttonPrestamosCrear
            // 
            this.buttonPrestamosCrear.Location = new System.Drawing.Point(567, 343);
            this.buttonPrestamosCrear.Name = "buttonPrestamosCrear";
            this.buttonPrestamosCrear.Size = new System.Drawing.Size(113, 34);
            this.buttonPrestamosCrear.TabIndex = 14;
            this.buttonPrestamosCrear.Text = "Crear";
            this.buttonPrestamosCrear.UseVisualStyleBackColor = true;
            this.buttonPrestamosCrear.Click += new System.EventHandler(this.buttonPrestamosCrear_Click);
            // 
            // buttonPrestamosActualizar
            // 
            this.buttonPrestamosActualizar.Location = new System.Drawing.Point(567, 303);
            this.buttonPrestamosActualizar.Name = "buttonPrestamosActualizar";
            this.buttonPrestamosActualizar.Size = new System.Drawing.Size(113, 34);
            this.buttonPrestamosActualizar.TabIndex = 13;
            this.buttonPrestamosActualizar.Text = "Actualizar";
            this.buttonPrestamosActualizar.UseVisualStyleBackColor = true;
            this.buttonPrestamosActualizar.Click += new System.EventHandler(this.buttonPrestamosActualizar_Click);
            // 
            // textBoxPrestamosFechaEntrega
            // 
            this.textBoxPrestamosFechaEntrega.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxPrestamosFechaEntrega.Location = new System.Drawing.Point(443, 370);
            this.textBoxPrestamosFechaEntrega.Name = "textBoxPrestamosFechaEntrega";
            this.textBoxPrestamosFechaEntrega.Size = new System.Drawing.Size(100, 33);
            this.textBoxPrestamosFechaEntrega.TabIndex = 12;
            // 
            // labelPrestamosFechaEntrega
            // 
            this.labelPrestamosFechaEntrega.AutoSize = true;
            this.labelPrestamosFechaEntrega.Location = new System.Drawing.Point(295, 373);
            this.labelPrestamosFechaEntrega.Name = "labelPrestamosFechaEntrega";
            this.labelPrestamosFechaEntrega.Size = new System.Drawing.Size(132, 26);
            this.labelPrestamosFechaEntrega.TabIndex = 11;
            this.labelPrestamosFechaEntrega.Text = "Fecha Entrega";
            // 
            // textBoxPrestamosPR
            // 
            this.textBoxPrestamosPR.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxPrestamosPR.Location = new System.Drawing.Point(443, 272);
            this.textBoxPrestamosPR.Name = "textBoxPrestamosPR";
            this.textBoxPrestamosPR.Size = new System.Drawing.Size(100, 33);
            this.textBoxPrestamosPR.TabIndex = 12;
            // 
            // labelPrestamosPR
            // 
            this.labelPrestamosPR.AutoSize = true;
            this.labelPrestamosPR.Location = new System.Drawing.Point(383, 275);
            this.labelPrestamosPR.Name = "labelPrestamosPR";
            this.labelPrestamosPR.Size = new System.Drawing.Size(44, 26);
            this.labelPrestamosPR.TabIndex = 11;
            this.labelPrestamosPR.Text = "PR#";
            // 
            // textBoxPrestamosFechaRecogida
            // 
            this.textBoxPrestamosFechaRecogida.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxPrestamosFechaRecogida.Location = new System.Drawing.Point(443, 321);
            this.textBoxPrestamosFechaRecogida.Name = "textBoxPrestamosFechaRecogida";
            this.textBoxPrestamosFechaRecogida.Size = new System.Drawing.Size(100, 33);
            this.textBoxPrestamosFechaRecogida.TabIndex = 12;
            // 
            // labelPrestamosFechaRecogida
            // 
            this.labelPrestamosFechaRecogida.AutoSize = true;
            this.labelPrestamosFechaRecogida.Location = new System.Drawing.Point(283, 324);
            this.labelPrestamosFechaRecogida.Name = "labelPrestamosFechaRecogida";
            this.labelPrestamosFechaRecogida.Size = new System.Drawing.Size(144, 26);
            this.labelPrestamosFechaRecogida.TabIndex = 11;
            this.labelPrestamosFechaRecogida.Text = "Fecha Recogida";
            // 
            // listViewPrestamos
            // 
            this.listViewPrestamos.BackColor = System.Drawing.Color.WhiteSmoke;
            this.listViewPrestamos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderPrestamoPR,
            this.columnHeaderPrestamoRecogida,
            this.columnHeaderPrestamoEntrega,
            this.columnHeaderPrestamoUsuario,
            this.columnHeaderPrestamoLibro,
            this.columnHeaderPrestamoEmpleado});
            this.listViewPrestamos.FullRowSelect = true;
            this.listViewPrestamos.Location = new System.Drawing.Point(5, 42);
            this.listViewPrestamos.MultiSelect = false;
            this.listViewPrestamos.Name = "listViewPrestamos";
            this.listViewPrestamos.Size = new System.Drawing.Size(682, 203);
            this.listViewPrestamos.TabIndex = 10;
            this.listViewPrestamos.UseCompatibleStateImageBehavior = false;
            this.listViewPrestamos.View = System.Windows.Forms.View.Details;
            this.listViewPrestamos.SelectedIndexChanged += new System.EventHandler(this.listViewPrestamos_SelectedIndexChanged);
            // 
            // columnHeaderPrestamoPR
            // 
            this.columnHeaderPrestamoPR.Text = "PR#";
            // 
            // columnHeaderPrestamoRecogida
            // 
            this.columnHeaderPrestamoRecogida.Text = "Recogida";
            this.columnHeaderPrestamoRecogida.Width = 99;
            // 
            // columnHeaderPrestamoEntrega
            // 
            this.columnHeaderPrestamoEntrega.Text = "Entrega";
            this.columnHeaderPrestamoEntrega.Width = 108;
            // 
            // columnHeaderPrestamoUsuario
            // 
            this.columnHeaderPrestamoUsuario.Text = "Usuario";
            // 
            // columnHeaderPrestamoLibro
            // 
            this.columnHeaderPrestamoLibro.Text = "Libro";
            // 
            // columnHeaderPrestamoEmpleado
            // 
            this.columnHeaderPrestamoEmpleado.Text = "Empleado";
            // 
            // buttonCargarPrestamos
            // 
            this.buttonCargarPrestamos.BackColor = System.Drawing.Color.Gainsboro;
            this.buttonCargarPrestamos.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.buttonCargarPrestamos.FlatAppearance.BorderSize = 0;
            this.buttonCargarPrestamos.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCargarPrestamos.ForeColor = System.Drawing.Color.Black;
            this.buttonCargarPrestamos.Location = new System.Drawing.Point(523, -4);
            this.buttonCargarPrestamos.Margin = new System.Windows.Forms.Padding(0);
            this.buttonCargarPrestamos.Name = "buttonCargarPrestamos";
            this.buttonCargarPrestamos.Size = new System.Drawing.Size(169, 40);
            this.buttonCargarPrestamos.TabIndex = 9;
            this.buttonCargarPrestamos.Text = "Cargar Préstamos";
            this.buttonCargarPrestamos.UseVisualStyleBackColor = false;
            this.buttonCargarPrestamos.Click += new System.EventHandler(this.buttonCargarPrestamos_Click);
            // 
            // labelPrestamosEmpleado
            // 
            this.labelPrestamosEmpleado.AutoSize = true;
            this.labelPrestamosEmpleado.Location = new System.Drawing.Point(8, 328);
            this.labelPrestamosEmpleado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPrestamosEmpleado.Name = "labelPrestamosEmpleado";
            this.labelPrestamosEmpleado.Size = new System.Drawing.Size(97, 26);
            this.labelPrestamosEmpleado.TabIndex = 0;
            this.labelPrestamosEmpleado.Text = "Empleado";
            // 
            // labelPrestamosLibro
            // 
            this.labelPrestamosLibro.AutoSize = true;
            this.labelPrestamosLibro.Location = new System.Drawing.Point(50, 388);
            this.labelPrestamosLibro.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPrestamosLibro.Name = "labelPrestamosLibro";
            this.labelPrestamosLibro.Size = new System.Drawing.Size(55, 26);
            this.labelPrestamosLibro.TabIndex = 0;
            this.labelPrestamosLibro.Text = "Libro";
            // 
            // labelPrestamosUsuario
            // 
            this.labelPrestamosUsuario.AutoSize = true;
            this.labelPrestamosUsuario.Location = new System.Drawing.Point(28, 268);
            this.labelPrestamosUsuario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPrestamosUsuario.Name = "labelPrestamosUsuario";
            this.labelPrestamosUsuario.Size = new System.Drawing.Size(77, 26);
            this.labelPrestamosUsuario.TabIndex = 0;
            this.labelPrestamosUsuario.Text = "Usuario";
            // 
            // imageListAplicacion
            // 
            this.imageListAplicacion.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListAplicacion.ImageStream")));
            this.imageListAplicacion.TransparentColor = System.Drawing.Color.Transparent;
            this.imageListAplicacion.Images.SetKeyName(0, "libro.png");
            this.imageListAplicacion.Images.SetKeyName(1, "personas.png");
            this.imageListAplicacion.Images.SetKeyName(2, "prestamo.PNG");
            // 
            // buttonClose
            // 
            this.buttonClose.BackColor = System.Drawing.Color.Gainsboro;
            this.buttonClose.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.buttonClose.FlatAppearance.BorderSize = 0;
            this.buttonClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClose.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClose.ForeColor = System.Drawing.Color.DimGray;
            this.buttonClose.Location = new System.Drawing.Point(661, 0);
            this.buttonClose.Margin = new System.Windows.Forms.Padding(0);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(30, 34);
            this.buttonClose.TabIndex = 7;
            this.buttonClose.Text = "X";
            this.buttonClose.UseVisualStyleBackColor = false;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // buttonAcercaDe
            // 
            this.buttonAcercaDe.BackColor = System.Drawing.Color.Gainsboro;
            this.buttonAcercaDe.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.buttonAcercaDe.FlatAppearance.BorderSize = 0;
            this.buttonAcercaDe.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttonAcercaDe.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.buttonAcercaDe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAcercaDe.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAcercaDe.ForeColor = System.Drawing.Color.DimGray;
            this.buttonAcercaDe.Location = new System.Drawing.Point(631, 0);
            this.buttonAcercaDe.Margin = new System.Windows.Forms.Padding(0);
            this.buttonAcercaDe.Name = "buttonAcercaDe";
            this.buttonAcercaDe.Size = new System.Drawing.Size(30, 34);
            this.buttonAcercaDe.TabIndex = 7;
            this.buttonAcercaDe.Text = "?";
            this.buttonAcercaDe.UseVisualStyleBackColor = false;
            this.buttonAcercaDe.Click += new System.EventHandler(this.buttonAcercaDe_Click);
            // 
            // textBoxPrestamosUsuario
            // 
            this.textBoxPrestamosUsuario.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxPrestamosUsuario.Location = new System.Drawing.Point(112, 265);
            this.textBoxPrestamosUsuario.Name = "textBoxPrestamosUsuario";
            this.textBoxPrestamosUsuario.Size = new System.Drawing.Size(144, 33);
            this.textBoxPrestamosUsuario.TabIndex = 12;
            // 
            // textBoxPrestamosEmpleado
            // 
            this.textBoxPrestamosEmpleado.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxPrestamosEmpleado.Location = new System.Drawing.Point(112, 321);
            this.textBoxPrestamosEmpleado.Name = "textBoxPrestamosEmpleado";
            this.textBoxPrestamosEmpleado.Size = new System.Drawing.Size(144, 33);
            this.textBoxPrestamosEmpleado.TabIndex = 12;
            // 
            // textBoxPrestamosLibro
            // 
            this.textBoxPrestamosLibro.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxPrestamosLibro.Location = new System.Drawing.Point(112, 385);
            this.textBoxPrestamosLibro.Name = "textBoxPrestamosLibro";
            this.textBoxPrestamosLibro.Size = new System.Drawing.Size(144, 33);
            this.textBoxPrestamosLibro.TabIndex = 12;
            // 
            // FormMauiDB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(691, 471);
            this.Controls.Add(this.buttonAcercaDe);
            this.Controls.Add(this.buttonClose);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormMauiDB";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aplicacion de Base de Datos";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown_1);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            this.tabControl1.ResumeLayout(false);
            this.tabPageLibros.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPageCategorias.ResumeLayout(false);
            this.tabPageCategorias.PerformLayout();
            this.tabPageEstilos.ResumeLayout(false);
            this.tabPageEstilos.PerformLayout();
            this.tabPageAutores.ResumeLayout(false);
            this.tabPageAutores.PerformLayout();
            this.tabPagePersonas.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPageEmpleados.ResumeLayout(false);
            this.tabPageEmpleados.PerformLayout();
            this.tabPageUsuarios.ResumeLayout(false);
            this.tabPageUsuarios.PerformLayout();
            this.tabPagePrestamo.ResumeLayout(false);
            this.tabPagePrestamo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView listViewEmpleado;
        private System.Windows.Forms.ColumnHeader columnHeaderEM;
        private System.Windows.Forms.ColumnHeader columnHeaderNombreEmpleado;
        private System.Windows.Forms.ColumnHeader columnHeaderApellidosEmpleado;
        private System.Windows.Forms.ColumnHeader columnHeaderTurnoEmpleado;
        private System.Windows.Forms.Label labelEM;
        private System.Windows.Forms.TextBox textBoxApellidosEmpleado;
        private System.Windows.Forms.Label labelNombre;
        private System.Windows.Forms.TextBox textBoxNombreEmpleado;
        private System.Windows.Forms.Label labelApellidosEmpleado;
        private System.Windows.Forms.TextBox textBoxTurnoEmpleado;
        private System.Windows.Forms.Label labelTurnoempleado;
        private System.Windows.Forms.TextBox textBoxEM;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPagePersonas;
        private System.Windows.Forms.ImageList imageListAplicacion;
        private System.Windows.Forms.Button buttonActualizarEmpleado;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Button buttonAcercaDe;
        private System.Windows.Forms.Label labelPrestamosUsuario;
        private System.Windows.Forms.TabPage tabPagePrestamo;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPageEmpleados;
        private System.Windows.Forms.TabPage tabPageUsuarios;
        private System.Windows.Forms.Button buttonCrearEmpleado;
        private System.Windows.Forms.Button buttonBorrarEmpleado;
        private System.Windows.Forms.Button buttonBorrarUsuario;
        private System.Windows.Forms.Button buttonCrearUsuario;
        private System.Windows.Forms.Button buttonActualizarUsuario;
        private System.Windows.Forms.Label labelDireccionUsuario;
        private System.Windows.Forms.Label labelApellidosUsuario;
        private System.Windows.Forms.TextBox textBoxUS;
        private System.Windows.Forms.TextBox textBoxApellidosUsuario;
        private System.Windows.Forms.TextBox textBoxNombreUsuario;
        private System.Windows.Forms.Label labelNombreUsuario;
        private System.Windows.Forms.TextBox textBoxDireccionUsuario;
        private System.Windows.Forms.Label labelUS;
        private System.Windows.Forms.ListView listViewUsuario;
        private System.Windows.Forms.ColumnHeader columnHeaderUS;
        private System.Windows.Forms.ColumnHeader columnHeaderNombreUsuario;
        private System.Windows.Forms.ColumnHeader columnHeaderApellidosUsuario;
        private System.Windows.Forms.ColumnHeader columnHeaderDireccionUsuario;
        private System.Windows.Forms.TabPage tabPageLibros;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPageEstilos;
        private System.Windows.Forms.TabPage tabPageAutores;
        private System.Windows.Forms.ListView listViewEstiloLibro;
        private System.Windows.Forms.ColumnHeader columnHeaderLIEstilo;
        private System.Windows.Forms.ColumnHeader columnHeaderNombreEstilo;
        private System.Windows.Forms.ColumnHeader columnHeaderFechaEstilo;
        private System.Windows.Forms.ColumnHeader columnHeaderEditorialEstilo;
        private System.Windows.Forms.ColumnHeader columnHeaderAutorEstilo;
        private System.Windows.Forms.ListView listViewAutoresLibro;
        private System.Windows.Forms.ColumnHeader columnHeaderLIAutor;
        private System.Windows.Forms.ColumnHeader columnHeaderNombreAutor;
        private System.Windows.Forms.ColumnHeader columnHeaderFechaAutor;
        private System.Windows.Forms.ColumnHeader columnHeaderEditorialAutor;
        private System.Windows.Forms.ListView listViewEstilo;
        private System.Windows.Forms.ColumnHeader columnHeaderEstiloLV;
        private System.Windows.Forms.ColumnHeader columnHeaderCountEstilo;
        private System.Windows.Forms.ListView listViewAutores;
        private System.Windows.Forms.ColumnHeader columnHeaderAutorLV;
        private System.Windows.Forms.ColumnHeader columnHeaderCountAutor;
        private System.Windows.Forms.TabPage tabPageCategorias;
        private System.Windows.Forms.ListView listViewCategoria;
        private System.Windows.Forms.ColumnHeader columnHeaderCategoriaLV;
        private System.Windows.Forms.ColumnHeader columnHeaderCountCategoria;
        private System.Windows.Forms.ListView listViewCategoriaLibro;
        private System.Windows.Forms.ColumnHeader columnHeaderLICategoria;
        private System.Windows.Forms.ColumnHeader columnHeaderNombreCategoria;
        private System.Windows.Forms.ColumnHeader columnHeaderFechaCategoria;
        private System.Windows.Forms.ColumnHeader columnHeaderEditorialCategoria;
        private System.Windows.Forms.ColumnHeader columnHeaderAutorCategoria;
        private System.Windows.Forms.Button buttonCargarLibros;
        private System.Windows.Forms.Button buttonCargarPersonas;
        private System.Windows.Forms.Button buttonCargarPrestamos;
        private System.Windows.Forms.Button buttonAutorBorrar;
        private System.Windows.Forms.Button buttonAutorCrear;
        private System.Windows.Forms.Button buttonAutorActualizar;
        private System.Windows.Forms.Label labelAutorEditorial;
        private System.Windows.Forms.Label labelAutorFecha;
        private System.Windows.Forms.TextBox textBoxAutorLI;
        private System.Windows.Forms.TextBox textBoxAutorFecha;
        private System.Windows.Forms.TextBox textBoxAutorNombre;
        private System.Windows.Forms.Label labelAutorNombre;
        private System.Windows.Forms.TextBox textBoxAutorEditorial;
        private System.Windows.Forms.Label labelAutorLI;
        private System.Windows.Forms.Button buttonEstiloBorrar;
        private System.Windows.Forms.Button buttonEstiloCrear;
        private System.Windows.Forms.Button buttonEstiloActualizar;
        private System.Windows.Forms.Label labelEstiloAutor;
        private System.Windows.Forms.Label labelEstiloEditorial;
        private System.Windows.Forms.Label labelEstiloFecha;
        private System.Windows.Forms.TextBox textBoxEstiloLI;
        private System.Windows.Forms.TextBox textBoxEstiloFecha;
        private System.Windows.Forms.TextBox textBoxEstiloNombre;
        private System.Windows.Forms.Label labelEstiloNombre;
        private System.Windows.Forms.TextBox textBoxEstiloAutor;
        private System.Windows.Forms.TextBox textBoxEstiloEditorial;
        private System.Windows.Forms.Label labelEstiloLI;
        private System.Windows.Forms.Button buttonCategoriaBorrar;
        private System.Windows.Forms.Button buttonCategoriaCrear;
        private System.Windows.Forms.Button buttonCategoriaActualizar;
        private System.Windows.Forms.Label labelCategoriaAutor;
        private System.Windows.Forms.Label labelCategoriaEditorial;
        private System.Windows.Forms.Label labelCategoriaFecha;
        private System.Windows.Forms.TextBox textBoxCategoriaLI;
        private System.Windows.Forms.TextBox textBoxCategoriaFecha;
        private System.Windows.Forms.TextBox textBoxCategoriaNombre;
        private System.Windows.Forms.Label labelCategoriaNombre;
        private System.Windows.Forms.TextBox textBoxCategoriaAutor;
        private System.Windows.Forms.TextBox textBoxCategoriaEditorial;
        private System.Windows.Forms.Label labelCategoriaLI;
        private System.Windows.Forms.ListView listViewPrestamos;
        private System.Windows.Forms.ColumnHeader columnHeaderPrestamoPR;
        private System.Windows.Forms.ColumnHeader columnHeaderPrestamoRecogida;
        private System.Windows.Forms.ColumnHeader columnHeaderPrestamoEntrega;
        private System.Windows.Forms.ColumnHeader columnHeaderPrestamoUsuario;
        private System.Windows.Forms.ColumnHeader columnHeaderPrestamoLibro;
        private System.Windows.Forms.ColumnHeader columnHeaderPrestamoEmpleado;
        private System.Windows.Forms.Label labelPrestamosLibro;
        private System.Windows.Forms.TextBox textBoxPrestamosFechaEntrega;
        private System.Windows.Forms.Label labelPrestamosFechaEntrega;
        private System.Windows.Forms.TextBox textBoxPrestamosPR;
        private System.Windows.Forms.Label labelPrestamosPR;
        private System.Windows.Forms.TextBox textBoxPrestamosFechaRecogida;
        private System.Windows.Forms.Label labelPrestamosFechaRecogida;
        private System.Windows.Forms.Label labelPrestamosEmpleado;
        private System.Windows.Forms.Button buttonPrestamosCrear;
        private System.Windows.Forms.Button buttonPrestamosActualizar;
        private System.Windows.Forms.TextBox textBoxPrestamosLibro;
        private System.Windows.Forms.TextBox textBoxPrestamosEmpleado;
        private System.Windows.Forms.TextBox textBoxPrestamosUsuario;

    }
}

